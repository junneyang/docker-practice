# Hide Header []({{ site.repo }}/blob/master/docs/_i18n/{{ site.lang }}/examples/hide-header.md)

Use la opción `showHeader: false` para ocultar el header de bootstrap table. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" data-src="http://jsfiddle.net/wenyi/e3nk137y/22/embedded/html,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>